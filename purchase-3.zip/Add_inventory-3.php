kkkkk
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "abc_company";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handling the form submission
if (isset($_POST['submit_inventory'])) {
    $purchase_order_no = $_POST['purchase_order_no'];
    $purchase_invoice_no = $_POST['invoice_no'];
    $reference = $_POST['reference'];
    $invoice_date = $_POST['invoice_date'];
    $vendor_id = $_POST['vendor_id'];
    $vendor_company_name = $_POST['vendor_company_name'];
    $vendor_name = $_POST['vendor_name'];
    $vendor_tin_no = $_POST['vendor_tin_no'];
    $vendor_telephone = $_POST['vendor_telephone'];
    $purchaseperson_id = $_POST['purchaseperson_id'];
    $purchaseperson_name = $_POST['purchaseperson_name'];
    $product_name = $_POST['product_name'];
    $category = $_POST['category'];
    $sub_category = $_POST['sub_category'];
  
    $unit = $_POST['unit'];
    $sku = $_POST['sku'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $total = $quantity * $price;
    $payment_method = $_POST['payment_method'];

    $sql = "INSERT INTO inventory (purchase_order_no, purchase_invoice_no, reference, invoice_date, vendor_id, vendor_company_name, vendor_name, vendor_tin_no, vendor_telephone, purchaseperson_id, purchaseperson_name, product_name, category, sub_category, brand, unit, sku, quantity, price, total, payment_method)
    VALUES ('$purchase_order_no', '$purchase_invoice_no', '$reference', '$invoice_date', '$vendor_id', '$vendor_company_name', '$vendor_name', '$vendor_tin_no', '$vendor_telephone', '$purchaseperson_id', '$purchaseperson_name', '$product_name', '$category', '$sub_category', '$brand', '$unit', '$sku', '$quantity', '$price', '$total', '$payment_method')";

    if ($conn->query($sql) === TRUE) {
        $success_message = "Inventory added successfully!";
    } else {
        $error_message = "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>



<body>
 <div class="container my-4">
  <h1 class="text-center">ABC Company</h1>
  <h1 class="text-center">Inventory Purchase Invoice</h1>
  <h6 class="text-center">
   <Address> Bole , XXXXXX, Telephone , email </Address>
  </h6>

  <!-- Display success or error message -->
  <?php if (isset($success_message)): ?>
  <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
  <?php elseif (isset($error_message)): ?>
  <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
  <?php endif; ?>

  <!-- Purchase Form -->
  <div class="card p-4">
   <form action="add_inventory.php" method="POST" id="purchase_form">
    <!-- Sales General Information in One Row -->
    <div class="row row-input">
     <div class="col-md-2">
      <label for="purchase_order_no" class="form-label">Purchase Order No.</label>
      <input type="text" class="form-control" id="purchase_order_no" name="purchase_order_no" required>
     </div>
     <div class="col-md-2">
      <label for="purchase_invoice_no" class="form-label">Purchase Invoice No.</label>
      <input type="text" class="form-control" id="purchase_invoice_no" name="purchase_invoice_no" required>
     </div>
     <div class="col-md-2">
      <label for="reference" class="form-label">Reference</label>
      <input type="text" class="form-control" id="reference" name="reference" required>
     </div>

     <div class="col-md-2">
      <label for="invoiceDate" class="form-label">Invoice Date:</label>
      <input type="date" class="form-control" id="invoiceDate" name="invoice_date" required>
     </div>

     <!-- Vendor Information -->
     <div class="col-md-2">
      <label for="vendor_id" class="form-label">Vendor ID</label>
      <input type="text" class="form-control" id="vendor_id" name="vendor_id" required>
     </div>
     <div class="col-md-2">
      <label for="vendor_company_name" class="form-label">Vendor Company Name</label>
      <input type="text" class="form-control" id="vendor_company_name" name="vendor_company_name" required>
     </div>
     <div class="col-md-3">
      <label for="vendor_name" class="form-label">Vendor Name</label>
      <input type="text" class="form-control" id="vendor_name" name="vendor_name" required>
     </div>
     <div class="col-md-2">
      <label for="vendor_tin_no" class="form-label">Vendor TIN No.</label>
      <input type="text" class="form-control" id="vendor_tin_no" name="vendor_tin_no" required>
     </div>
     <div class="col-md-2">
      <label for="vendor_telephone" class="form-label">Vendor Telephone No.</label>
      <input type="text" class="form-control" id="vendor_telephone" name="vendor_telephone" required>
     </div>
    </div>

    <!-- Purchase Person Information -->
    <div class="row row-input">
     <div class="col-md-2">
      <label for="purchaseperson_id" class="form-label">Purchase Person ID</label>
      <input type="text" class="form-control" id="purchaseperson_id" name="purchaseperson_id" required>
     </div>
     <div class="col-md-2">
      <label for="purchaseperson_name" class="form-label">Purchase Person Name</label>
      <input type="text" class="form-control" id="purchaseperson_name" name="purchaseperson_name" required>
     </div>
    </div>

    <!-- Product Details -->
    <div class="row row-input">
     <div class="col-md-2">
      <label for="product_name" class="form-label">Product Name</label>
      <input type="text" class="form-control" id="product_name" name="product_name" required>
     </div>
     <div class="col-md-2">
      <label for="category" class="form-label">Category</label>
      <input type="text" class="form-control" id="category" name="category" required>
     </div>
     <div class="col-md-2">
      <label for="sub_category" class="form-label">Sub Category</label>
      <input type="text" class="form-control" id="sub_category" name="sub_category" required>
     </div>
     <div class="col-md-2">
      <label for="brand" class="form-label">Brand</label>
      <input type="text" class="form-control" id="brand" name="brand" required>
     </div>
     <div class="col-md-2">
      <label for="unit" class="form-label">Unit</label>
      <input type="text" class="form-control" id="unit" name="unit" required>
     </div>
     <div class="col-md-2">
      <label for="sku" class="form-label">SKU</label>
      <input type="text" class="form-control" id="sku" name="sku" required>
     </div>
    </div>

    <!-- Price and Quantity -->
    <div class="row row-input">
     <div class="col-md-2">
      <label for="quantity" class="form-label">Quantity</label>
      <input type="number" class="form-control" id="quantity" name="quantity" required>
     </div>
     <div class="col-md-2">
      <label for="price" class="form-label">Price</label>
      <input type="number" class="form-control" id="price" name="price" required>
     </div>
     <div class="col-md-2">
      <label for="total" class="form-label">Total</label>
      <input type="number" class="form-control" id="total" name="total" readonly>
     </div>
    </div>

    <!-- Payment Information -->
    <div class="col-md-2">
     <label for="payment_method" class="form-label">Payment Method</label>
     <select class="form-control" id="payment_method" name="payment_method" required>
      <option value="cash">Cash</option>
      <option value="cheque">Cheque</option>
      <option value="bank">Bank Transfer</option>
      <option value="other">Other</option>
     </select>
    </div>

    <!-- Submit Button -->
    <div class="form-group mt-3">
     <button type="submit" class="btn btn-primary" name="submit_inventory">Submit</button>
    </div>
   </form>
  </div>
 </div>
</body>


kkkkkkkkkkkkkkkkkk

<body>
 <div class="container my-4">
  <h1 class="text-center">ABC Company</h1>
  <h1 class="text-center">Inventory Purchase Invoice</h1>
  <h6 class="text-center">
   <Address> Bole , XXXXXX,Telephone , email </Address>
  </h6>

  <!-- Display success or error message -->
  <?php if (isset($success_message)): ?>
  <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
  <?php elseif (isset($error_message)): ?>
  <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
  <?php endif; ?>

  <!-- Sale Form -->
  <div class="card p-4">
   <form action="add_inventory.php" method="POST" id="purchase _form">
    <!-- Sales General Information in One Row -->
    <div class="row row-input">
     <div class="col-md-2">
      <label for="purchase _order_no" class="form-label">Purchase Order No.</label>
      <input type="text" class="form-control" id="purchase_order_no" name="purchase _order_no">
     </div>
     <div class="col-md-2">
      <label for="purchase _invoice_no" class="form-label">Purchase Invoice No.</label>
      <input type="text" class="form-control" id="purchase _invoice_no" name="purchase _invoice_no" required>
     </div>
     <div class="col-md-2">
      <label for="reference" class="form-label">Reference</label>
      <input type="text" class="form-control" id="reference" name="reference" required>
     </div>

     <div class="col-md-2">
      <label for="invoiceDate" class="form-label">Invoice Date:</label>
      <input type="date" class="form-control" id="invoiceDate" required>
     </div>

     <!-- Customer Information in One Row -->
     <div class="row row-input">

      <div class="col-md-2">
       <label for="vendor_id" class="form-label">vendor ID</label>
       <input type="text" class="form-control" id="vendor_id" name="vendor_id" required>
      </div>
      <div class="col-md-2">
       <label for="vendor_Company_name" class="form-label">vendor Company Name</label>
       <input type="text" class="form-control" id="vendor_company_name" name="vendor_company_name" required>
      </div>
      <div class="col-md-3">
       <label for="vendor_name" class="form-label">vendor Name</label>
       <input type="text" class="form-control" id="vendor_name" name="vendor_name" required>
      </div>
      <div class="col-md-2">
       <label for="vendor_TIN No." class="form-label">vendor TIN No</label>
       <input type="text" class="form-control" id="vendorr_TIN No" name="vendor_TIN No" required>
      </div>
      <div class="col-md-2">
       <label for="vendor_Telephone No." class="form-label">vendor Telephone No</label>
       <input type="text" class="form-control" id="vendor_Telephone No." name="vendor_Telephone No." required>
      </div>
      <div class="row row-input">
       <div class="col-md-2">
        <label for="purchase person_id" class="form-label">purchase Person ID</label>
        <input type="text" class="form-control" id="purchaseperson_id" name="purchaseperson_id" required>
       </div>

       <div class="col-md-2">
        <label for="purchaseperson_name" class="form-label">purchase Person Name</label>
        <input type="text" class="form-control" id="purchase person_name" name="purchase person_name" required>
       </div>

       kkkkkkkkkkkk

       <div class="card">
        <div class="card-body">
         <div class="row">
          <!-- Product Name -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Product Name</label>
            <input type="text" class="form-control" placeholder="Enter product name">
           </div>
          </div>

          <!-- Category -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Category</label>
            <select class="form-control select">
             <option>Choose Category</option>
             <option>Computers</option>
            </select>
           </div>
          </div>

          <!-- Sub Category -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Sub Category</label>
            <select class="form-control select">
             <option>Choose Sub Category</option>
             <option>Fruits</option>
            </select>
           </div>
          </div>

          <!-- Brand -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Brand</label>
            <select class="form-control select">
             <option>Choose Brand</option>
             <option>Brand</option>
            </select>
           </div>
          </div>

          <!-- Unit -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Unit</label>
            <select class="form-control select">
             <option>Choose Unit</option>
             <option>Unit</option>
            </select>
           </div>
          </div>

          <!-- SKU -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>SKU</label>
            <input type="text" class="form-control" placeholder="Enter SKU">
           </div>
          </div>

          <!-- Minimum Qty -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Minimum Qty</label>
            <input type="text" class="form-control" placeholder="Enter minimum quantity">
           </div>
          </div>

          <!-- Quantity -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Quantity</label>
            <input type="text" class="form-control" placeholder="Enter quantity">
           </div>
          </div>

          <!-- Description -->
          <div class="col-lg-12">
           <div class="form-group">
            <label>Description</label>
            <textarea class="form-control" placeholder="Enter product description"></textarea>
           </div>
          </div>

          <!-- Tax -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Tax</label>
            <select class="form-control select">
             <option>Choose Tax</option>
             <option>2%</option>
            </select>
           </div>
          </div>

          <!-- Discount Type -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Discount Type</label>
            <select class="form-control select">
             <option>Percentage</option>
             <option>10%</option>
             <option>20%</option>
            </select>
           </div>
          </div>

          <!-- Price -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Price</label>
            <input type="text" class="form-control" placeholder="Enter price">
           </div>
          </div>

          <!-- Status -->
          <div class="col-lg-3 col-sm-6 col-12">
           <div class="form-group">
            <label>Status</label>
            <select class="form-control select">
             <option>Closed</option>
             <option>Open</option>
            </select>
           </div>
          </div>

          <!-- Product Image -->
          <div class="col-lg-12">
           <div class="form-group">
            <label>Product Image</label>
            <div class="image-upload">
             <input type="file" class="form-control">
             <div class="image-uploads">
              <img src="assets/img/icons/upload.svg" alt="Upload Icon">
              <h4>Drag and drop a file to upload</h4>
             </div>
            </div>
           </div>
          </div>


          kkkkkk

          <div class="col-md-2">
           <label for="payment_method" class="form-label">Payment Method</label>
           <select class="form-control" id="payment_method" name="payment_method" required>
            <option value="cash">Cash</option>
            <option value="cash">Cheque</option>
            <option value="bank">Bank Transfer</option>
            <option value="cash">Other</option>
           </select>
          </div>
         </div>

         <!-- Item Details Table (Excel-style) -->

         <script>
         function calculateTotal(input) {
          const row = input.closest("tr");
          const quantity = parseFloat(row.querySelector('[name="quantity[]"]').value) || 0;
          const unitPrice = parseFloat(row.querySelector('[name="unit_price[]"]').value) || 0;
          const totalSales = quantity * unitPrice;
          row.querySelector('[name="total_sales[]"]').value = totalSales.toFixed(2);
          updateSalesSummary();
         }

         function addRow() {
          const table = document.getElementById("item_table").getElementsByTagName("tbody")[0];
          const newRow = table.insertRow();

          newRow.innerHTML = `
                <td><input type="text" class="form-control" name="item_id[]" required></td>
                <td><input type="text" class="form-control" name="item_description[]" required></td>
                <td><input type="text" class="form-control" name="gl_account[]" required></td>
                <td><input type="number" class="form-control" name="quantity[]" step="1" min="1" oninput="calculateTotal(this)" required></td>
                <td><input type="number" class="form-control" name="unit_price[]" step="0.01" min="0.01" oninput="calculateTotal(this)" required></td>
                <td><input type="number" class="form-control" name="total_sales[]" readonly></td>
                <td><input type="text" class="form-control" name="job_id[]"></td>
                <td><button type="button" class="btn btn-danger" onclick="removeRow(this)">Remove</button></td>
            `;
         }

         function removeRow(button) {
          const row = button.closest("tr");
          row.remove();
          updateSalesSummary();
         }

         function updateSalesSummary() {
          let totalBeforeVAT = 0;
          document.querySelectorAll('[name="total_sales[]"]').forEach(input => {
           totalBeforeVAT += parseFloat(input.value) || 0;
          });

          const vatAmount = totalBeforeVAT * 0.15;
          const totalWithVAT = totalBeforeVAT + vatAmount;

          document.getElementById("total_sales_before_vat").textContent = totalBeforeVAT.toFixed(2);
          document.getElementById("vat_amount").textContent = vatAmount.toFixed(2);
          document.getElementById("sales_with_vat").textContent = totalWithVAT.toFixed(2);

          document.getElementById("amount_in_words").textContent =
           `Total in Words: ${toWords(totalWithVAT)} Birr only.`;
         }

         function toWords(amount) {
          const ones = [
           "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
           "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
           "Seventeen", "Eighteen", "Nineteen",
          ];
          const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
          const scales = ["", "Thousand", "Million", "Billion"];

          if (amount === 0) return "Zero";

          const words = [];
          const numStr = Math.floor(amount).toString();
          const numParts = numStr.match(/.{1,3}(?=(.{3})*$)/g).reverse();

          numParts.forEach((part, index) => {
           if (parseInt(part) === 0) return;

           let str = "";
           const hundreds = Math.floor(part / 100);
           const remainder = part % 100;
           if (hundreds > 0) str += ones[hundreds] + " Hundred ";
           if (remainder < 20) str += ones[remainder];
           else str += tens[Math.floor(remainder / 10)] + " " + ones[remainder % 10];

           words.push(str + (scales[index] ? " " + scales[index] : ""));
          });

          return words.reverse().join(" ").trim();
         }
         </script>
         </head>

         <body>
          <div class="container mt-3">


           <table id="item_table" class="table table-bordered">
            <thead>
             <tr>
              <th>Item ID</th>
              <th>Description</th>
              <th>GL Account</th>
              <th>Quantity</th>
              <th>Unit Price</th>
              <th>Total Sales</th>
              <th>Job ID</th>
              <th>Action</th>
             </tr>
            </thead>
            <tbody>
             <!-- Rows will be added dynamically -->
            </tbody>
           </table>

           <button type="button" class="btn btn-primary mb-4" onclick="addRow()">Add Item</button>

           <div>
            <p><strong>Total Before VAT:</strong> Birr <span id="total_sales_before_vat"> 0.00</span></p>
            <p><strong>VAT (15%):</strong> Birr <span id="vat_amount"> 0.00</span></p>
            <p><strong>Total Sales with VAT:</strong> Birr <span id="sales_with_vat"> 0.00</span></p>
            <p id="amount_in_words"><strong>Total in Words: </strong> Zero Birr only.</p>
           </div>
          </div>


          <div class="signature">
           <div>
            <p>Prepared By:</p>
            <p>____________________</p>
           </div>
           <div>
            <p>Checked By:</p>
            <p>____________________</p>
           </div>
           <div>
            <p>Approved By:</p>
            <p>____________________</p>
           </div>
          </div>
        </div>


        <div class="text-center mt-4">
         <button type="submit" class="btn btn-primary">Save purchase </button>
        </div>


</body>

</html>
kkkkkkkkkkkk

<title>Product Add</title>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom Styles -->
<style>
body {
 font-family: Arial, sans-serif;
 background-color: #f4f6f9;
}

.page-wrapper {
 padding: 20px;
}

.page-header {
 margin-bottom: 20px;
}

.card {
 border-radius: 8px;
 box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
 background-color: #fff;
 padding: 20px;
}

.form-group label {
 font-weight: bold;
}

.btn-submit,
.btn-cancel {
 width: 150px;
 border-radius: 5px;
 font-weight: 600;
 transition: background-color 0.3s ease;
}

.btn-submit {
 background-color: #28a745;
 color: white;
}

.btn-submit:hover {
 background-color: #218838;
}

.btn-cancel {
 background-color: #dc3545;
 color: white;
}

.btn-cancel:hover {
 background-color: #c82333;
}

.image-upload {
 border: 2px dashed #6c757d;
 border-radius: 5px;
 padding: 40px;
 text-align: center;
 background-color: #f8f9fa;
}

.image-upload input[type="file"] {
 display: none;
}

.image-upload img {
 max-width: 100px;
 margin-bottom: 20px;
}

.image-uploads h4 {
 color: #6c757d;
}

.form-control,
.select {
 border-radius: 5px;
 height: 40px;
 padding: 10px;
}

.col-lg-3 {
 margin-bottom: 15px;
}
</style>
</head>

<body>

 <div class="page-wrapper">
  <div class="content">
   <div class="page-header">
    <div class="page-title">
     <h4>Product Add</h4>
     <h6>Create new product</h6>
    </div>
   </div>

   <div class="card">
    <div class="card-body">
     <div class="row">
      <!-- Product Name -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Product Name</label>
        <input type="text" class="form-control" placeholder="Enter product name">
       </div>
      </div>

      <!-- Category -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Category</label>
        <select class="form-control select">
         <option>Choose Category</option>
         <option>Computers</option>
        </select>
       </div>
      </div>

      <!-- Sub Category -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Sub Category</label>
        <select class="form-control select">
         <option>Choose Sub Category</option>
         <option>Fruits</option>
        </select>
       </div>
      </div>

      <!-- Brand -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Brand</label>
        <select class="form-control select">
         <option>Choose Brand</option>
         <option>Brand</option>
        </select>
       </div>
      </div>

      <!-- Unit -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Unit</label>
        <select class="form-control select">
         <option>Choose Unit</option>
         <option>Unit</option>
        </select>
       </div>
      </div>

      <!-- SKU -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>SKU</label>
        <input type="text" class="form-control" placeholder="Enter SKU">
       </div>
      </div>

      <!-- Minimum Qty -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Minimum Qty</label>
        <input type="text" class="form-control" placeholder="Enter minimum quantity">
       </div>
      </div>

      <!-- Quantity -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Quantity</label>
        <input type="text" class="form-control" placeholder="Enter quantity">
       </div>
      </div>

      <!-- Description -->
      <div class="col-lg-12">
       <div class="form-group">
        <label>Description</label>
        <textarea class="form-control" placeholder="Enter product description"></textarea>
       </div>
      </div>

      <!-- Tax -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Tax</label>
        <select class="form-control select">
         <option>Choose Tax</option>
         <option>2%</option>
        </select>
       </div>
      </div>

      <!-- Discount Type -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Discount Type</label>
        <select class="form-control select">
         <option>Percentage</option>
         <option>10%</option>
         <option>20%</option>
        </select>
       </div>
      </div>

      <!-- Price -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Price</label>
        <input type="text" class="form-control" placeholder="Enter price">
       </div>
      </div>

      <!-- Status -->
      <div class="col-lg-3 col-sm-6 col-12">
       <div class="form-group">
        <label>Status</label>
        <select class="form-control select">
         <option>Closed</option>
         <option>Open</option>
        </select>
       </div>
      </div>

      <!-- Product Image -->
      <div class="col-lg-12">
       <div class="form-group">
        <label>Product Image</label>
        <div class="image-upload">
         <input type="file" class="form-control">
         <div class="image-uploads">
          <img src="assets/img/icons/upload.svg" alt="Upload Icon">
          <h4>Drag and drop a file to upload</h4>
         </div>
        </div>
       </div>
      </div>

      <!-- Buttons -->
      <div class="col-lg-12">
       <a href="javascript:void(0);" class="btn btn-submit me-2">Submit</a>
       <a href="productlist.html" class="btn btn-cancel">Cancel</a>
      </div>
     </div>
    </div>
   </div>

  </div>
 </div>

 <!-- JS Scripts -->
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
kkkkkkk
<?php 
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ABC_Company";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$items = $conn->query("SELECT item_id, item_description, unit_price FROM inventory");

// Function to convert numbers to words

// Handle invoice creation
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $invoice_no = $_POST['invoice_no'];
    $reference = $_POST['reference'];
    $GL_account = $_POST['GL_account'];
    $items_data = $_POST['items'];
    $grand_total = $_POST['grand_total_after_vat'];
    $date = $_POST['date'];

    $sql = "INSERT INTO invoices (invoice_no, reference, GL_account, total_amount, created_at) 
            VALUES ('$invoice_no', '$reference', '$GL_account', '$grand_total', '$date')";
    
    if ($conn->query($sql) === TRUE) {
        $invoice_id = $conn->insert_id;
        
        foreach ($items_data as $item) {
            $item_id = $item['item_id'];
            $quantity = $item['quantity'];
            $unit_price = $item['unit_price'];
            $total_price = $item['total_price'];
            
            $sql = "INSERT INTO invoice_items (invoice_id, item_id, quantity, GL_account, unit_price, total_price) 
                    VALUES ('$invoice_id', '$item_id', '$quantity', '$GL_account', '$unit_price', '$total_price')";
            $conn->query($sql);
        }
        header("Location: invoice.php?success=1");
        exit;
    } else {
        $error = "Error: " . $conn->error;
    }
}
$conn->close();
?>

<div class="container mt-4">
 <h2 class="mb-3 text-center">Create Invoice</h2>

 <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

 <form method="POST">
  <div class="row mb-2">
   <div class="col-md-3">
    <label>Invoice No.</label>
    <input type="text" name="invoice_no" class="form-control" required>
   </div>
   <div class="col-md-3">
    <label>Reference</label>
    <input type="text" name="reference" class="form-control">
   </div>
   <div class="col-md-3">
    <label>GL Account</label>
    <input type="text" name="GL_account" class="form-control" required>
   </div>
   <div class="col-md-3">
    <label>Date</label>
    <input type="text" name="date" class="form-control datepicker" required>
   </div>
  </div>

  <table class="table table-sm table-bordered">
   <thead class="table-dark">
    <tr>
     <th>Item</th>
     <th>Unit Price</th>
     <th>Qty</th>
     <th>Total</th>
     <th>Action</th>
    </tr>
   </thead>
   <tbody id="items-container"></tbody>
  </table>

  <button type="button" class="btn btn-secondary btn-sm" onclick="addItemRow()">Add Item</button>

  <div class="text-end mt-3">
   <h5>Grand Total Before VAT: Birr <span id="grand-total-before-vat">0.00</span></h5>
   <h5>VAT (15%): Birr <span id="vat-total">0.00</span></h5>
   <h5>Grand Total After VAT: Birr <span id="grand-total-after-vat">0.00</span></h5>
   <h5>Amount in Words: <span id="amount-in-words">Zero</span></h5>
   <input type="hidden" name="grand_total_after_vat" id="grand-total-after-vat-input">
   <button type="submit" class="btn btn-primary w-100 mt-3">Create Invoice</button>
  </div>
 </form>
</div>



<script>
$(document).ready(function() {
 $('.datepicker').datepicker({
  format: 'yyyy-mm-dd',
  autoclose: true
 });
});

function addItemRow() {
 let row = `<tr>
        <td>
            <select class="form-select item-select" name="items[][item_id]" required>
                <option value="">Select Item</option>
                <?php while($item = $items->fetch_assoc()): ?>
                <option value="<?= $item['item_id'] ?>" data-price="<?= $item['unit_price'] ?>">
                    <?= htmlspecialchars($item['item_description']) ?>
                </option>
                <?php endwhile; ?>
            </select>
        </td>
        <td><input type="text" name="items[][unit_price]" class="form-control price" readonly></td>
        <td><input type="number" name="items[][quantity]" class="form-control qty" required></td>
        <td><input type="text" name="items[][total_price]" class="form-control total" readonly></td>
        <td><button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">×</button></td>
    </tr>`;

 $('#items-container').append(row);
 attachRowEvents();
}

function removeRow(btn) {
 $(btn).closest('tr').remove();
 calculateTotals();
}

function attachRowEvents() {
 $('.item-select').change(function() {
  let row = $(this).closest('tr');
  row.find('.price').val(formatNumber($(this).find('option:selected').data('price')));
  calculateTotals();
 });

 $('.qty').on('input', function() {
  calculateTotals();
 });
}

function calculateTotals() {
 let grandTotal = 0;
 $('.total').each(function() {
  let row = $(this).closest('tr');
  let price = parseFloat(row.find('.price').val().replace(/,/g, '')) || 0;
  let qty = parseFloat(row.find('.qty').val()) || 0;
  let total = price * qty;
  row.find('.total').val(formatNumber(total));
  grandTotal += total;
 });

 let vat = grandTotal * 0.15;
 let grandTotalAfterVAT = grandTotal + vat;
 $('#grand-total-before-vat').text(formatNumber(grandTotal));
 $('#vat-total').text(formatNumber(vat));
 $('#grand-total-after-vat').text(formatNumber(grandTotalAfterVAT));
 $('#amount-in-words').text(numberToWords(grandTotalAfterVAT));
}

function formatNumber(num) {
 return num.toLocaleString('en-US', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
 });
}
</script>
kkkkkkkkkkkkkkkkkkk

<!-- PHP code remains the same as previous revision -->
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "abc_company";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handling the form submission
if (isset($_POST['submit_inventory'])) {
    $purchase_order_no = $_POST['purchase_order_no'];
    $purchase_invoice_no = $_POST['invoice_no'];
    $reference = $_POST['reference'];
    $invoice_date = $_POST['invoice_date'];
    $vendor_id = $_POST['vendor_id'];
    $vendor_company_name = $_POST['vendor_company_name'];
    $vendor_name = $_POST['vendor_name'];
    $vendor_tin_no = $_POST['vendor_tin_no'];
    $vendor_telephone = $_POST['vendor_telephone'];
    $purchaseperson_id = $_POST['purchaseperson_id'];
    $purchaseperson_name = $_POST['purchaseperson_name'];
    $product_name = $_POST['product_name'];
    $category = $_POST['category'];
    $sub_category = $_POST['sub_category'];
    $brand = $_POST['brand'];
    $unit = $_POST['unit'];
    $sku = $_POST['sku'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $total = $quantity * $price;
    $payment_method = $_POST['payment_method'];

    $sql = "INSERT INTO inventory (purchase_order_no, purchase_invoice_no, reference, invoice_date, vendor_id, vendor_company_name, vendor_name, vendor_tin_no, vendor_telephone, purchaseperson_id, purchaseperson_name, product_name, category, sub_category, brand, unit, sku, quantity, price, total, payment_method)
    VALUES ('$purchase_order_no', '$purchase_invoice_no', '$reference', '$invoice_date', '$vendor_id', '$vendor_company_name', '$vendor_name', '$vendor_tin_no', '$vendor_telephone', '$purchaseperson_id', '$purchaseperson_name', '$product_name', '$category', '$sub_category', '$brand', '$unit', '$sku', '$quantity', '$price', '$total', '$payment_method')";

    if ($conn->query($sql) === TRUE) {
        $success_message = "Inventory added successfully!";
    } else {
        $error_message = "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>



<body>
 <div class="container my-4">
  <h1 class="text-center">ABC Company</h1>
  <h1 class="text-center">Inventory Purchase Invoice</h1>
  <h6 class="text-center">
   <Address> Bole , XXXXXX, Telephone , email </Address>
  </h6>

  <!-- Display success or error message -->
  <?php if (isset($success_message)): ?>
  <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
  <?php elseif (isset($error_message)): ?>
  <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
  <?php endif; ?>

  <!-- Purchase Form -->
  <div class="card p-4">
   <form action="add_inventory.php" method="POST" id="purchase_form">
    <!-- Sales General Information in One Row -->
    <div class="row row-input">
     <div class="col-md-2">
      <label for="purchase_order_no" class="form-label">Purchase Order No.</label>
      <input type="text" class="form-control" id="purchase_order_no" name="purchase_order_no" required>
     </div>
     <div class="col-md-2">
      <label for="purchase_invoice_no" class="form-label">Purchase Invoice No.</label>
      <input type="text" class="form-control" id="purchase_invoice_no" name="purchase_invoice_no" required>
     </div>
     <div class="col-md-2">
      <label for="reference" class="form-label">Reference</label>
      <input type="text" class="form-control" id="reference" name="reference" required>
     </div>

     <div class="col-md-2">
      <label for="invoiceDate" class="form-label">Invoice Date:</label>
      <input type="date" class="form-control" id="invoiceDate" name="invoice_date" required>
     </div>

     <!-- Vendor Information -->
     <div class="col-md-2">
      <label for="vendor_id" class="form-label">Vendor ID</label>
      <input type="text" class="form-control" id="vendor_id" name="vendor_id" required>
     </div>
     <div class="col-md-2">
      <label for="vendor_company_name" class="form-label">Vendor Company Name</label>
      <input type="text" class="form-control" id="vendor_company_name" name="vendor_company_name" required>
     </div>
     <div class="col-md-3">
      <label for="vendor_name" class="form-label">Vendor Name</label>
      <input type="text" class="form-control" id="vendor_name" name="vendor_name" required>
     </div>
     <div class="col-md-2">
      <label for="vendor_tin_no" class="form-label">Vendor TIN No.</label>
      <input type="text" class="form-control" id="vendor_tin_no" name="vendor_tin_no" required>
     </div>
     <div class="col-md-2">
      <label for="vendor_telephone" class="form-label">Vendor Telephone No.</label>
      <input type="text" class="form-control" id="vendor_telephone" name="vendor_telephone" required>
     </div>
    </div>

    <!-- Purchase Person Information -->
    <div class="row row-input">
     <div class="col-md-2">
      <label for="purchaseperson_id" class="form-label">Purchase Person ID</label>
      <input type="text" class="form-control" id="purchaseperson_id" name="purchaseperson_id" required>
     </div>
     <div class="col-md-2">
      <label for="purchaseperson_name" class="form-label">Purchase Person Name</label>
      <input type="text" class="form-control" id="purchaseperson_name" name="purchaseperson_name" required>
     </div>
    </div>

    <!-- Product Details -->
    <div class="row row-input">
     <div class="col-md-2">
      <label for="product_name" class="form-label">Product Name</label>
      <input type="text" class="form-control" id="product_name" name="product_name" required>
     </div>
     <div class="col-md-2">
      <label for="category" class="form-label">Category</label>
      <input type="text" class="form-control" id="category" name="category" required>
     </div>
     <div class="col-md-2">
      <label for="sub_category" class="form-label">Sub Category</label>
      <input type="text" class="form-control" id="sub_category" name="sub_category" required>
     </div>
     <div class="col-md-2">
      <label for="brand" class="form-label">Brand</label>
      <input type="text" class="form-control" id="brand" name="brand" required>
     </div>
     <div class="col-md-2">
      <label for="unit" class="form-label">Unit</label>
      <input type="text" class="form-control" id="unit" name="unit" required>
     </div>
     <div class="col-md-2">
      <label for="sku" class="form-label">SKU</label>
      <input type="text" class="form-control" id="sku" name="sku" required>
     </div>
    </div>

    <!-- Price and Quantity -->
    <div class="row row-input">
     <div class="col-md-2">
      <label for="quantity" class="form-label">Quantity</label>
      <input type="number" class="form-control" id="quantity" name="quantity" required>
     </div>
     <div class="col-md-2">
      <label for="price" class="form-label">Price</label>
      <input type="number" class="form-control" id="price" name="price" required>
     </div>
     <div class="col-md-2">
      <label for="total" class="form-label">Total</label>
      <input type="number" class="form-control" id="total" name="total" readonly>
     </div>
    </div>

    <!-- Payment Information -->
    <div class="col-md-2">
     <label for="payment_method" class="form-label">Payment Method</label>
     <select class="form-control" id="payment_method" name="payment_method" required>
      <option value="cash">Cash</option>
      <option value="cheque">Cheque</option>
      <option value="bank">Bank Transfer</option>
      <option value="other">Other</option>
     </select>
    </div>

    <!-- Submit Button -->
    <div class="form-group mt-3">
     <button type="submit" class="btn btn-primary" name="submit_inventory">Submit</button>
    </div>
   </form>
  </div>
 </div>
</body>

<!-- Enhanced HTML with improved styling -->
<div class="container mt-5">
 <h2 class="text-center mb-4">Create Invoice</h2>

 <?php if (isset($error)): ?>
 <div class='alert alert-danger'><?= htmlspecialchars($error) ?></div>
 <?php endif; ?>

 <form method="POST">
  <!-- Form fields remain the same -->

  <!-- Item Table with enhanced styling -->
  <table class="table table-hover invoice-table">
   <thead class="table-primary">
    <tr>
     <th style="width: 35%">Item</th>
     <th style="width: 15%">Unit Price</th>
     <th style="width: 15%">Quantity</th>
     <th style="width: 15%">Total</th>
     <th style="width: 10%">Action</th>
    </tr>
   </thead>
   <tbody id="items-container">
    <!-- Rows will be added here dynamically -->
   </tbody>
  </table>

  <button type="button" class="btn btn-add-item" onclick="addItemRow()">
   <i class="fas fa-plus-circle"></i> Add Item
  </button>

  <!-- Grand Total Section with enhanced styling -->
  <div class="total-section mt-4">
   <div class="total-row">
    <span>Grand Total Before VAT:</span>
    <span>Birr <span id="grand-total-before-vat">0.00</span></span>
   </div>
   <div class="total-row">
    <span>VAT (15%):</span>
    <span>Birr <span id="vat-total">0.00</span></span>
   </div>
   <div class="total-row highlight">
    <span>Grand Total After VAT:</span>
    <span>Birr <span id="grand-total-after-vat">0.00</span></span>
   </div>
   <div class="amount-words">
    Amount in Words: <span id="amount-in-words">Zero</span>
   </div>
   <input type="hidden" name="grand_total_after_vat" id="grand-total-after-vat-input">
   <button type="submit" class="btn btn-submit">
    <i class="fas fa-file-invoice"></i> Create Invoice
   </button>
  </div>
 </form>
</div>

<!-- JavaScript fixes for Add Item functionality -->
<script>
// Fixed Add Item Row function with proper event delegation
function addItemRow() {
 const row = `<tr>
        <td>
            <select class="form-select item-select" name="items[][item_id]" required>
                <option value="">Select Item</option>
                <?php foreach($items as $item): ?>
                <option value="<?= $item['item_id'] ?>" data-price="<?= $item['unit_price'] ?>">
                    <?= htmlspecialchars($item['item_description']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </td>
        <td><input type="text" name="items[][unit_price]" class="form-control price" readonly></td>
        <td><input type="number" name="items[][quantity]" class="form-control qty" min="1" value="1" required></td>
        <td><input type="text" name="items[][total_price]" class="form-control total" readonly></td>
        <td class="text-center"><button type="button" class="btn btn-remove" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>
    </tr>`;

 $('#items-container').append(row);

 // Initialize select2 for better dropdown styling
 $('.item-select').last().select2({
  theme: 'bootstrap-5',
  placeholder: "Select an item",
  allowClear: true
 });
}

// Event delegation for dynamic elements
$(document).on('change', '.item-select', function() {
 const price = parseFloat($(this).find('option:selected').data('price')) || 0;
 $(this).closest('tr').find('.price').val(price.toFixed(2));
 calculateTotals();
}).on('input', '.qty', function() {
 calculateTotals();
});

// Rest of JavaScript remains similar with improved numberToWords function
</script>

<!-- Enhanced CSS -->
<style>
.container {
 max-width: 1000px;
 margin: 2rem auto;
 background: #ffffff;
 padding: 2rem;
 border-radius: 12px;
 box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

.invoice-table {
 border-collapse: separate;
 border-spacing: 0 8px;
 margin: 1.5rem 0;
}

.invoice-table thead th {
 background: #2c3e50;
 color: white;
 border: none;
 padding: 1rem;
}

.invoice-table tbody tr {
 background: #f8f9fa;
 transition: all 0.2s ease;
}

.invoice-table tbody tr:hover {
 transform: translateY(-2px);
 box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.btn-add-item {
 background: #3498db;
 color: white;
 padding: 0.5rem 1.5rem;
 border-radius: 8px;
 transition: all 0.3s ease;
}

.btn-add-item:hover {
 background: #2980b9;
 transform: translateY(-1px);
}

.btn-remove {
 color: #e74c3c;
 background: none;
 border: none;
 padding: 0.25rem;
}

.btn-remove:hover {
 color: #c0392b;
}

.total-section {
 background: #f8f9fa;
 padding: 1.5rem;
 border-radius: 8px;
 margin-top: 2rem;
}

.total-row {
 display: flex;
 justify-content: space-between;
 margin: 0.5rem 0;
 font-size: 1.1rem;
}

.highlight {
 color: #27ae60;
 font-weight: 600;
 font-size: 1.2rem;
}

.amount-words {
 margin: 1.5rem 0;
 padding: 1rem;
 background: #ecf0f1;
 border-radius: 6px;
 font-style: italic;
}

.btn-submit {
 background: #27ae60;
 color: white;
 padding: 1rem 2rem;
 width: 100%;
 font-size: 1.1rem;
 border-radius: 8px;
 transition: all 0.3s ease;
}

.btn-submit:hover {
 background: #219a52;
 transform: translateY(-1px);
}

.select2-container--bootstrap-5 .select2-selection {
 border-radius: 8px;
 padding: 0.375rem;
}

@media (max-width: 768px) {
 .container {
  padding: 1rem;
  margin: 1rem;
 }

 .invoice-table td,
 .invoice-table th {
  padding: 0.75rem;
 }
}
</style>

<!-- Additional required CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.5.2/dist/select2-bootstrap4.min.css"
 rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">